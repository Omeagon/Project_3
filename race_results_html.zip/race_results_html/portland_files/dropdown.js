define(["jquery", "onscreen"], function ($) {
    var Dropdown;
    return Dropdown = (function () {
        function Dropdown(options) {
            this.options = options;
            this.options = $.extend({}, this.defaults(), this.options);
            this.delegateEvents();
        }

        Dropdown.prototype.defaults = function () {
            return {
                triggerItem: ".filter-link",
                active: "--active",
                dropdownLink: ".dropdown-links__dropdown a",
                selectMobile: ".select-lists__select-wrap select"
            };
        };

        Dropdown.prototype.delegateEvents = function () {
            var selectHovered, _self;
            _self = this;
            this.options.$triggerItem = $(this.options.triggerItem);
            this.options.$active = $(this.options.active);
            this.options.$dropdownLink = $(this.options.dropdownLink);
            this.options.$selectMobile = $(this.options.selectMobile);
            selectHovered = false;
            this.options.$triggerItem.hover(function () {
                return selectHovered = true;
            }, function () {
                return selectHovered = false;
            });
            $('body').off('click').on('click', function () {
                if (selectHovered === false) {
                    return $('body').find('.dropdown-links__item--active').removeClass('dropdown-links__item--active');
                }
            });
            this.options.$triggerItem.children('.dropdown-links__dropdown-link').off('click').on("click", function (e) {
                var $this;
                e.preventDefault();
                $this = $(this);
                if ($this.parent().hasClass(_self.options.active)) {
                    return $this.parent().removeClass(_self.options.active);
                } else {
                    _self.options.$triggerItem.removeClass(_self.options.active);
                    return $this.parent().addClass(_self.options.active);
                }
            });
            this.options.$dropdownLink.on('click', function () {                
                if (!$(this).hasClass('stats-drop-down'))
                {
                    var url;
                    url = $(this).attr('href');
                    return window.location.href = url;
                }
            });
            this.options.$selectMobile.on('change', function () {
                if (!$(this).hasClass('stats-drop-down'))
                {
                    var url;
                    url = $(this).val();
                    if ($(this).hasClass('stats-mobile-report-drop-down') && url != '')
                    {
                         return window.open(url);
                    }
                    else if (!$(this).hasClass('stats-mobile-report-drop-down'))
                    {
                        return window.location.href = url;                       
                    }
                }
            });
        };

        return Dropdown;

    })();
});
