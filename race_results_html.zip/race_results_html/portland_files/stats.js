﻿define(["jquery", "dynatable"], function ($) {
    var Stats;
    var SETTINGS = SETTINGS || {};
    SETTINGS.SeasonDropDownData = [];
    SETTINGS.SeasonEvents = [];
    SETTINGS.Series = '';
    SETTINGS.isDebug = true;
    //STATS.Environment = 'http://www.indycar.com'; //Prod
    SETTINGS.Environment = ''; //Dev
    SETTINGS.racetable, SETTINGS.qualtable, SETTINGS.qualovaltable, SETTINGS.qualindytable, SETTINGS.practable, SETTINGS.alldrivertable, SETTINGS.yeardrivertable, SETTINGS.alltimewinnerstable;

    return Stats = (function () {
        function Stats(options) {
            this.options = options;
            this.options = $.extend({}, this.defaults(), this.options);
            this.delegateEvents();
        }

        Stats.prototype.defaults = function () {
            return {
                SeasonDropDownData: [],
                SeasonEvents: [],
                Series: '',
                isDebug: true,
                Environment: ''
            };
        };

        Stats.prototype.delegateEvents = function () {
            var _self;
            _self = this;

            SETTINGS.Series = $('#hdnSeries').val();

            var mobileSeriesDD = $('#series-option');
            if (mobileSeriesDD != null) {
                mobileSeriesDD.val(SETTINGS.Series);
            }

            $('#series-option').on('change', MobileSeriesChanged);

            if (location.href.indexOf("RoadToIndy") != -1) {
                $('#firestoneSub').trigger('click');
            }

            $('#year-option').on('change', SeasonYearChanged);
            $('#event-option').on('change', SeasonEventChanged);
            $('#session-option').on('change', SeasonSessionChanged);
            $('#driver-year-option').on('change', DriverYearChanged);
            $('#driver-driver-option').on('change', DriverDriverChanged);
            $('#driver-event-option').on('change', DriverEventChanged);
            $('#alltime-year-option').on('change', AllTimeYearChanged);
            $('#alltime-series-option').on('change', AllTimeSeriesChanged);
            $('.series-tab').on('click', this.SelectedSeriesChanged);

            this.BuildSeasonsDropDowns();
            this.BuildDriversDropDowns();
            this.BuildAllTimeDropDowns();

            $('#driver-select-event').hide();

        };

        Stats.prototype.MobileSeriesChanged = function () {
            var $self = $(this),
                    SeriesID = $('#series-option').val(),
                    SeriesTitle = $('#series-option').text();

            SETTINGS.Series = SeriesID;
            $('#statsHeading').text(SeriesTitle);
            this.BuildSeasonsDropDowns();
            this.BuildDriversDropDowns();
            this.BuildAllTimeDropDowns();
        };

        Stats.prototype.SelectedSeriesChanged = function () {
            var $self = $(this),
                SeriesID = $self.data('seriesid'),
                SeriesTitle = $self.attr('title');

            if ($self.attr('id') == 'indySub') {
                $('#seasonTab').click();
                $('#driver-select-type').show();
                $('#alltimeTab').show();
            } else {
                $('#seasonTab').click();
                $('#driver-select-type').hide();
                $('#alltimeTab').hide();
            }

            $('.series-tab').removeClass('secondary-nav__nav-link--active');
            $self.addClass('secondary-nav__nav-link--active');

            SETTINGS.Series = SeriesID;

            Stats.prototype.BuildSeasonsDropDowns();
            Stats.prototype.BuildDriversDropDowns();
            Stats.prototype.BuildAllTimeDropDowns();
        };

        Stats.prototype.BuildSeasonsDropDowns = function () {
            $.ajax({
                type: "GET",
                async: false,
                dataType: "json",
                url: SETTINGS.Environment + '/Services/IndyStats.svc/SeasonDropDown?id=' + SETTINGS.Series,
                success: this.BuildOptionsFromData,
                error: this.ErrorHandler
            });
        };

        Stats.prototype.BuildDriversDropDowns = function () {
            $('#driver-year-option').empty();
            $.ajax({
                type: "GET",
                async: false,
                dataType: "json",
                url: SETTINGS.Environment + '/Services/IndyStats.svc/YearsBySeries?series=' + SETTINGS.Series,
                success: function (data) {
                    var yearLength = data.length;
                    for (var i = 0; i < yearLength; i++) {
                        $('#driver-year-option')
                    .append($("<option></option>")
                    .attr("value", data[i])
                    .text(data[i]));
                    }
                },
                error: this.ErrorHandler
            });

            BuildDriverNamesDropDown();
            BuildDriverEventsDropDown();
        };
        Stats.prototype.BuildAllTimeDropDowns = function () {
            $('#alltime-year-option').empty();
            $.ajax({
                type: "GET",
                async: false,
                dataType: "json",
                url: SETTINGS.Environment + '/Services/IndyStats.svc/AllTimeWinnerYears',
                success: function (data) {
                    var yearLength = data.length;
                    for (var i = 0; i < yearLength; i++) {
                        $('#alltime-year-option')
                    .append($("<option></option>")
                    .attr("value", data[i])
                    .text(data[i]));
                    }
                },
                error: this.ErrorHandler
            });

            BuildAllTimeSeriesDropDown();
        };
        Stats.prototype.BuildOptionsFromData = function (data) {
            SETTINGS.SeasonDropDownData = data;
            var yearLength = SETTINGS.SeasonDropDownData.length;
            var selectedYear = 0;
            $('#year-option').empty();
            for (var i = 0; i < yearLength; i++) {
                $('#year-option')
                    .append($("<option></option>")
                    .attr("value", SETTINGS.SeasonDropDownData[i].Year)
                    .text(SETTINGS.SeasonDropDownData[i].Year));

                if ($('#hdnYear').val() != '' && $('#hdnYear').val() == SETTINGS.SeasonDropDownData[i].Year) {
                    selectedYear = i;
                    $('#year-option').val($('#hdnYear').val());
                }
            }

            SETTINGS.SeasonEvents = SETTINGS.SeasonDropDownData[selectedYear].Events;
            SETTINGS.SeasonSessions = SETTINGS.SeasonEvents[0].Sessions;
            BuildSeasonEvents();
            BuildSeasonSessions();
        };



        MobileSeriesChanged = function () {
            var $self = $(this),
                    SeriesID = $('#series-option').val(),
                    SeriesTitle = $('#series-option').text();

            STATS.Series = SeriesID;
            $('#statsHeading').text(SeriesTitle);
            BuildSeasonsDropDowns();
            BuildDriversDropDowns();

        };

        SeasonYearChanged = function () {
            var year = $('#year-option').val();
            var yearLength = SETTINGS.SeasonDropDownData.length;
            for (var i = 0; i < yearLength; i++) {
                if (year == SETTINGS.SeasonDropDownData[i].Year) {
                    SETTINGS.SeasonEvents = SETTINGS.SeasonDropDownData[i].Events;
                    SETTINGS.SeasonSessions = SETTINGS.SeasonEvents[0].Sessions;
                    BuildSeasonEvents();
                    BuildSeasonSessions();
                }
            }
        };

        SeasonEventChanged = function () {
            var eventName = $('#event-option').val();
            var evLength = SETTINGS.SeasonEvents.length;
            for (var i = 0; i < evLength; i++) {
                if (eventName == SETTINGS.SeasonEvents[i].EventName) {
                    SETTINGS.SeasonSessions = SETTINGS.SeasonEvents[i].Sessions;
                    BuildSeasonSessions();
                }
            }
        };

        SeasonSessionChanged = function () {
            var eventSessionID = $('#session-option').val();
            $.ajax({
                type: "GET",
                dataType: "json",
                url: SETTINGS.Environment + '/Services/IndyStats.svc/EventsSessionDetails?id=' + eventSessionID,
                success: function (data) {

                    $('#season-event-name').html(data.EventName);
                    $('#season-session-name').html(data.SessionName);
                    var displayDate;
                    displayDate = data.SessionDateFormatted;
                    $('#season-session-date').html(displayDate);
                    if (data.SessionReports.length > 0) {
                        $("#session-reports-wrap").css("display", "inline-block");
                        $("#session-reports").empty();
                        $("#session-reports")
                                .append($("<option></option>")
                                .attr("value", "")
                                .text("Session Reports"));
                        for (var i = 0; i < data.SessionReports.length; i++) {
                            $("#session-reports")
                                .append($("<option></option>")
                                .attr("value", "http://www.imscdn.com/" + data.SessionReports[i].Url)
                                .text(data.SessionReports[i].DocumentType));
                        }
                    } else {
                        $("#session-reports-wrap").css("display", "none");
                    }

                    HideSeasonTables();
                    var results = JSON.parse(JSON.stringify(data.records).replace(/null/g, '"-"'));
                    if (data.SessionType == 'R') {
                        $("#race-season").show();
                        if (SETTINGS.racetable == null) {
                            SETTINGS.racetable = $('#race-season').dynatable({
                                features: {
                                    paginate: false,
                                    sort: false,
                                    pushState: true,
                                    search: false,
                                    recordCount: false,
                                    perPageSelect: false
                                },
                                dataset: {
                                    records: results
                                },
                            }).data("dynatable");
                        } else {
                            SETTINGS.racetable.settings.dataset.originalRecords = results;
                            SETTINGS.racetable.process();
                        }
                    }
                    else if (data.SessionType == 'Q') {
                        if (data.TrackType == 'I') {
                            $("#qual-indy-season").show();
                            if (SETTINGS.qualindytable == null) {
                                SETTINGS.qualindytable = $('#qual-indy-season').dynatable({
                                    features: {
                                        paginate: false,
                                        sort: false,
                                        pushState: true,
                                        search: false,
                                        recordCount: false,
                                        perPageSelect: false
                                    },
                                    dataset: {
                                        records: JSON.parse(JSON.stringify(data.records).replace(/null/g, '"-"'))
                                    }
                                }).data("dynatable");
                            } else {
                                SETTINGS.qualindytable.settings.dataset.originalRecords = results;
                                SETTINGS.qualindytable.process();
                            }
                        } else if (data.TrackType == 'O') {
                            $("#qual-oval-season").show();
                            if (SETTINGS.qualovaltable == null) {
                                SETTINGS.qualovaltable = $('#qual-oval-season').dynatable({
                                    features: {
                                        paginate: false,
                                        sort: false,
                                        pushState: true,
                                        search: false,
                                        recordCount: false,
                                        perPageSelect: false
                                    },
                                    dataset: {
                                        records: JSON.parse(JSON.stringify(data.records).replace(/null/g, '"-"'))
                                    }
                                }).data("dynatable");
                            } else {
                                SETTINGS.qualovaltable.settings.dataset.originalRecords = results;
                                SETTINGS.qualovaltable.process();
                            }
                        } else {
                            $("#qual-season").show();
                            if (SETTINGS.qualtable == null) {
                                SETTINGS.qualtable = $('#qual-season').dynatable({
                                    features: {
                                        paginate: false,
                                        sort: false,
                                        pushState: true,
                                        search: false,
                                        recordCount: false,
                                        perPageSelect: false
                                    },
                                    dataset: {
                                        records: JSON.parse(JSON.stringify(data.records).replace(/null/g, '"-"'))
                                    }
                                }).data("dynatable");
                            } else {
                                SETTINGS.qualtable.settings.dataset.originalRecords = results;
                                SETTINGS.qualtable.process();
                            }
                        }
                    }
                    else if (data.SessionType == 'P') {
                        $("#practice-season").show();
                        if (SETTINGS.practable == null) {
                            SETTINGS.practable = $('#practice-season').dynatable({
                                features: {
                                    paginate: false,
                                    sort: false,
                                    pushState: true,
                                    search: false,
                                    recordCount: false,
                                    perPageSelect: false
                                },
                                dataset: {
                                    records: JSON.parse(JSON.stringify(data.records).replace(/null/g, '"-"'))
                                }
                            }).data("dynatable");
                        } else {
                            SETTINGS.practable.settings.dataset.originalRecords = results;
                            SETTINGS.practable.process();
                        }
                    }
                },
                error: this.ErrorHandler
            });
        }

        BuildSeasonEvents = function () {
            var eventLength = SETTINGS.SeasonEvents.length;
            $('#event-option').empty();
            for (var i = 0; i < eventLength; i++) {
                $('#event-option')
                    .append($("<option></option>")
                    .attr("value", SETTINGS.SeasonEvents[i].EventName)
                    .text(SETTINGS.SeasonEvents[i].EventName));

                if ($('#hdnEvent').val() != '' && $('#hdnEvent').val() == SETTINGS.SeasonEvents[i].EventName.toLowerCase().replace(/ /g, '-')) {
                    SETTINGS.SeasonSessions = SETTINGS.SeasonEvents[i].Sessions;
                    $('#event-option').val(SETTINGS.SeasonEvents[i].EventName);
                }
            }
        };

        BuildSeasonSessions = function () {
            var sessionLength = SETTINGS.SeasonSessions.length;
            $('#session-option').empty();
            for (var i = 0; i < sessionLength; i++) {
                $('#session-option')
                    .append($("<option></option>")
                    .attr("value", SETTINGS.SeasonSessions[i].EventsSessionID)
                    .text(SETTINGS.SeasonSessions[i].SessionName));
                var session = SETTINGS.SeasonSessions[i].SessionName.toLowerCase().replace(/ /g, '-');
                if ($('#hdnSession').val() != '' && $('#hdnSession').val() == session) {
                    $('#session-option').val(SETTINGS.SeasonSessions[i].EventsSessionID);
                }
            }

            this.SeasonSessionChanged();
        };

        DriverYearChanged = function () {
            BuildDriverNamesDropDown();
            BuildDriverEventsDropDown();
        };

        BuildDriverNamesDropDown = function () {
            var year = $('#driver-year-option').val();
            $.ajax({
                type: "GET",
                dataType: "json",
                url: SETTINGS.Environment + '/Services/IndyStats.svc/DriversByYear?year=' + year + '&id=' + SETTINGS.Series,
                success: function (data) {
                    var dataLength = data.length;
                    $('#driver-driver-option').empty();
                    $('#driver-driver-option')
                            .append($("<option></option>")
                            .attr("value", "")
                            .text("All Drivers"));
                    for (var i = 0; i < dataLength; i++) {
                        $('#driver-driver-option')
                            .append($("<option></option>")
                            .attr("value", data[i].DriverOverrideID)
                            .text(data[i].LastName + ', ' + data[i].FirstName));
                    }
                    BuildAllDriversDisplay();
                },
                error: this.ErrorHandler
            });
        };

        BuildDriverEventsDropDown = function () {
            var year = $('#driver-year-option').val();
            $.ajax({
                type: "GET",
                dataType: "json",
                url: SETTINGS.Environment + '/Services/IndyStats.svc/EventsByYearSeries?year=' + year + '&id=' + SETTINGS.Series,
                success: function (data) {
                    var dataLength = data.length;
                    $('#driver-event-option').empty();
                    $('#driver-event-option')
                            .append($("<option></option>")
                            .attr("value", "")
                            .text("Select Event"));
                    for (var i = 0; i < dataLength; i++) {
                        $('#driver-event-option')
                            .append($("<option></option>")
                            .attr("value", data[i].EventID)
                            .text(data[i].EventName));
                    }
                },
                error: this.ErrorHandler
            });
        };

        DriverDriverChanged = function () {
            var year = $('#driver-year-option').val();
            var driverID = $('#driver-driver-option').val();
            $('#driver-event-option').val($("#river-event-option option:first").val());
            if (driverID.length) {
                $('#driver-select-event').show();
                BuildDriverYearDisplay();
            } else {
                $('#driver-select-event').hide();
                BuildAllDriversDisplay();
            }
        };

        DriverEventChanged = function () {
            var year = $('#driver-year-option').val();
            var driverID = $('#driver-driver-option').val();
            var eventID = $('#driver-event-option').val();

            if (eventID.length) {
                BuildDriverEventDisplay();
            } else {
                $('#driver-select-type').hide();
                $('#driver-select-event').show();
                this.BuildDriverYearDisplay();
            }
        };

        BuildDriverEventDisplay = function () {
            var year = $('#driver-year-option').val();
            var driverID = $('#driver-driver-option').val();
            var eventID = $('#driver-event-option').val();
            $.ajax({
                type: "GET",
                dataType: "json",
                url: SETTINGS.Environment + "/Services/IndyStats.svc/DriverEventDetails?driverID=" + driverID + "&eventID=" + eventID,
                success: function (data) {
                    HideDriverTables();
                    $("#event-driver").show();
                    $("#event-driver").empty();

                    for (var i = 0; i < data.EventSessionList.length; i++) {
                        var result = '';
                        if (data.EventSessionList[i].SessionType == 'R') {
                            result = '<div class="primary-heading">' + data.EventSessionList[i].SessionName + '</div><div class="event-sub-text">' + data.EventSessionList[i].SessionDate + '</div><table class="generic-table generic-table--lap-table" style="margin-bottom: 15px;">'
                                + '<thead><tr><th class="generic-table__header">Rank</th><th class="generic-table__header">No.</th><th class="generic-table__header">Start</th><th class="generic-table__header">Laps</th><th class="generic-table__header">Total Time</th><th class="generic-table__header">Laps Led</th><th class="generic-table__header">Status</th><th class="generic-table__header">Points</th><th class="generic-table__header">Avg. Speed</th><th class="generic-table__header">Pit Stops</th></tr></thead>'
                                + '<tr><td class="generic-table__column">' + data.EventSessionList[i].Result.PositionFinish + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.CarNumber + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.PositionStart + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.LapsComplete + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.ElapsedTime + '</td><td class="generic-table__column">'
                            if (data.EventSessionList[i].Result.LapsLed != null) {
                                result += data.EventSessionList[i].Result.LapsLed;
                            } else {
                                result += '-';
                            }
                            result += '</td><td class="generic-table__column">';
                            if (data.EventSessionList[i].Result.Status != null) {
                                result += data.EventSessionList[i].Result.Status
                            } else {
                                result += '-';
                            }
                            result += '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.PointsEarned + '</td><td class="generic-table__column">';
                            if (data.EventSessionList[i].Result.SpeedAvgFormatted != null) {
                                result += String(data.EventSessionList[i].Result.SpeedAvgFormatted);
                            }
                            result += '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.PitStops + '</td></tr></table>';
                            $("#event-driver").append(result);

                        }
                        else if (data.EventSessionList[i].SessionType == 'P' && data.EventSessionList[i].Result.BestLapTime != null) {
                            result = '<div class="primary-heading">' + data.EventSessionList[i].SessionName + '</div><div class="event-sub-text">' + data.EventSessionList[i].SessionDate + '</div><table class="generic-table generic-table--lap-table" style="margin-bottom: 15px;">'
                                + '<thead><tr><th class="generic-table__header">No.</th><th class="generic-table__header">Best Time</th><th class="generic-table__header">In Lap</th><th class="generic-table__header">Best Speed</th><th class="generic-table__header">Total Laps</th><th class="generic-table__header">Difference</th><th class="generic-table__header">Gap</th></tr></thead>'
                            + '<tr><td class="generic-table__column">' + data.EventSessionList[i].Result.CarNumber + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.BestLapTime + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.InLap + '</td><td class="generic-table__column">';
                            if (data.EventSessionList[i].Result.BestSpeed != null) {
                                result += data.EventSessionList[i].Result.BestSpeed.toFixed(3)
                            }
                            result += '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.LapsComplete + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.Difference + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.Gap + '</td></tr></table>';

                            $("#event-driver").append(result);
                        }
                        else if (data.EventSessionList[i].SessionType == 'Q' && data.EventSessionList[i].Result.BestLapTime != null) {
                            result = '<div class="primary-heading">' + data.EventSessionList[i].SessionName + '</div><div class="event-sub-text">' + data.EventSessionList[i].SessionDate + '</div><table class="generic-table generic-table--lap-table" style="margin-bottom: 15px;">'
                                + '<thead><tr><th class="generic-table__header">No.</th><th class="generic-table__header">Best Time</th><th class="generic-table__header">Best Speed</th><th class="generic-table__header">Best Lap</th><th class="generic-table__header">Total Laps</th><th class="generic-table__header">Difference</th><th class="generic-table__header">Gap</th></tr></thead>'
                            + '<tr><td class="generic-table__column">' + data.EventSessionList[i].Result.CarNumber + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.BestLapTime + '</td><td class="generic-table__column">';
                            if (data.EventSessionList[i].Result.BestSpeed != null) {
                                result += data.EventSessionList[i].Result.BestSpeed.toFixed(3)
                            }
                            result += '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.InLap + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.LapsComplete + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.Difference + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.Gap + '</td></tr></table>';

                            $("#event-driver").append(result);
                        }
                        else if (data.EventSessionList[i].SessionType == 'Q' && data.EventSessionList[i].Result.SpeedAvgFormatted != null) {
                            result = '<div class="primary-heading">' + data.EventSessionList[i].SessionName + '</div><div class="event-sub-text">' + data.EventSessionList[i].SessionDate + '</div><table class="generic-table generic-table--lap-table" style="margin-bottom: 15px;">'
                                + '<thead><tr><th class="generic-table__header">Rank</th><th class="generic-table__header">No.</th><th class="generic-table__header">Lap 1 Time</th><th class="generic-table__header">Lap 2 Time</th>';
                            if (data.EventSessionList[i].Result.QualLap3 != null) {
                                result += '<th class="generic-table__header">Lap 3 Time</th>';
                            }
                            if (data.EventSessionList[i].Result.QualLap4 != null) {
                                result += '<th class="generic-table__header">Lap 4 Time</th>';
                            }
                            result += '<th class="generic-table__header">Elapsed Time</th><th class="generic-table__header">Average Speed</th></tr></thead>'
                                + '<tr><td class="generic-table__column">' + data.EventSessionList[i].Result.PositionFinish + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.CarNumber + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.QualLap1 + '</td><td class="generic-table__column">' + data.EventSessionList[i].Result.QualLap2 + '</td>';

                            if (data.EventSessionList[i].Result.QualLap3 != null) {
                                result += '<td class="generic-table__column">' + data.EventSessionList[i].Result.QualLap3 + '</td>';
                            }
                            if (data.EventSessionList[i].Result.QualLap4 != null) {
                                result += '<td class="generic-table__column">' + data.EventSessionList[i].Result.QualLap4 + '</td>';
                            }
                            result += '<td class="generic-table__column">' + data.EventSessionList[i].Result.ElapsedTime + '</td><td class="generic-table__column">';

                            if (data.EventSessionList[i].Result.SpeedAvg != null) {
                                result += String(data.EventSessionList[i].Result.SpeedAvgFormatted);
                            }
                            result += '</td></tr></table>';
                            $("#event-driver").append(result);
                        }
                    }

                    var header = '<h1 class="primary-heading">' + data.DriverName + '</h1><div class="sub-text">Championship Rank: ' + data.SeasonRank + '</div><div class="sub-text">' + data.EventName;

                    if (data.EventSessionList.length < 1) {
                        header += '- <em>No Results</em>';
                    }
                    header += '</div>';

                    $("#driver-results-header").html(header);
                },
                error: this.ErrorHandler
            });
        };

        BuildAllDriversDisplay = function () {
            var year = $('#driver-year-option').val();
            $.ajax({
                type: "GET",
                dataType: "json",
                url: SETTINGS.Environment + "/Services/IndyStats.svc/YearPointSummary?year=" + year + "&id=" + SETTINGS.Series,
                success: function (data) {
                    var dataLength = data.length;
                    HideDriverTables();
                    $("#all-driver").show();

                    var races = [];

                    $("#all-driver thead tr .dynamic-header").remove();

                    for (var i = 0; i < data.RaceAbbreviations.length; i++) {
                        if (races.indexOf(data.RaceAbbreviations[i].Track) == -1) {
                            races[i] = data.RaceAbbreviations[i].Track
                            $("#all-driver thead tr").append('<th class="generic-table__header dynamic-header" data-dynatable-column="' + data.RaceAbbreviations[i].Track.toLowerCase() + '">' + data.RaceAbbreviations[i].Track + '</th>');
                        } else {
                            if (races.indexOf(data.RaceAbbreviations[i].Track + '2') == -1) {
                                races[i] = data.RaceAbbreviations[i].Track + '2';
                                $("#all-driver thead tr").append('<th class="generic-table__header dynamic-header" data-dynatable-column="' + data.RaceAbbreviations[i].Track.toLowerCase() + '2">' + data.RaceAbbreviations[i].Track + '</th>');
                            } else {
                                races[i] = data.RaceAbbreviations[i].Track + '3';
                                $("#all-driver thead tr").append('<th class="generic-table__header dynamic-header" data-dynatable-column="' + data.RaceAbbreviations[i].Track.toLowerCase() + '3">' + data.RaceAbbreviations[i].Track + '</th>');
                            }
                        }
                    }
                    var drivers = JSON.parse("[" + data.AltDriverList.replace("\\\"", "\"") + "]");
                    $("#all-driver tbody").empty();
                    for (var i = 0; i < drivers.length; i++) {
                        var row = "<tr>";
                        $("#all-driver th").each(function () {
                            row += "<td class=\"generic-table__column\">" + drivers[i][$(this).data("dynatable-column")] + "</td>";
                        });
                        row += "</tr>";
                        $("#all-driver tbody").append(row);
                    }
                    //if (SETTINGS.alldriver == null) {
                    //    SETTINGS.alldriver = $('#all-driver').dynatable({
                    //        features: {
                    //            paginate: false,
                    //            sort: false,
                    //            pushState: true,
                    //            search: false,
                    //            recordCount: false,
                    //            perPageSelect: false
                    //        },
                    //        dataset: {
                    //            records: drivers
                    //        }
                    //    }).data("dynatable");
                    //} else {
                    //    SETTINGS.alldriver.settings.dataset.originalRecords = drivers;
                    //    SETTINGS.alldriver.process();
                    //    SETTINGS.alldriver.dom.update();
                    //}
                    $("#driver-results-header").html('<div id="point-standings-header" class="details float-left"><h1 class="primary-heading">' + data.SeriesTitle + '</h1><div class="sub-text">' + data.SortTitle + '</div><div class="sub-text">Last Updated: ' + data.UpdatedDate + '</div></div>');
                },
                error: this.ErrorHandler
            });
        };

        BuildDriverYearDisplay = function () {
            var year = $('#driver-year-option').val();
            var driverID = $('#driver-driver-option').val();
            $.ajax({
                type: "GET",
                dataType: "json",
                url: SETTINGS.Environment + "/Services/IndyStats.svc/DriverYearDetails?year=" + year + "&series=" + SETTINGS.Series + "&driverID=" + driverID,
                success: function (data) {
                    var dataLength = data.length;

                    HideDriverTables();
                    $("#year-driver").show();

                    if (SETTINGS.yeardrivertable == null) {
                        SETTINGS.yeardrivertable = $('#year-driver').dynatable({
                            features: {
                                paginate: false,
                                sort: false,
                                pushState: true,
                                search: false,
                                recordCount: false,
                                perPageSelect: false
                            },
                            dataset: {
                                records: JSON.parse(JSON.stringify(data.Results).replace(/null/g, '"-"'))
                            }
                        }).data("dynatable");
                    } else {
                        SETTINGS.yeardrivertable.settings.dataset.originalRecords = data.Results;
                        SETTINGS.yeardrivertable.process();
                    }

                    $("#driver-results-header").html('<h1 class="primary-heading">' + data.Name + '</h1><div class="sub-text">' + data.Year + ' Season Race Results</div>');


                    //$('table.stats-driver-year td.first .race-name').each(function () {
                    //    var $self = $(this),
                    //    length = 34,  // set to the number of characters you want to keep
                    //    pathname = $self.text(),
                    //    trimmedPathname = pathname.substring(0, Math.min(length, pathname.length));
                    //    $self.parent().attr('title', pathname);
                    //    if (pathname.length > length) {
                    //        $self.text(trimmedPathname).append(' ...');
                    //    };
                    //});
                },
                error: this.ErrorHandler
            });
        };


        AllTimeYearChanged = function () {
            BuildAllTimeSeriesDropDown();
        };
        AllTimeSeriesChanged = function () {
            var year = $('#alltime-year-option').val();
            var series = $('#alltime-series-option').val();
            $.ajax({
                type: "GET",
                dataType: "json",
                url: SETTINGS.Environment + '/Services/IndyStats.svc/AllTimeWinnersByYearSeries?year=' + year + '&series=' + series,
                success: function (data) {
                    var results = JSON.parse(JSON.stringify(data).replace(/null/g, '"-"'));
                    $("#race-alltime").show();
                    if (SETTINGS.alltimewinnerstable == null) {
                        SETTINGS.alltimewinnerstable = $('#race-alltime').dynatable({
                            features: {
                                paginate: false,
                                sort: false,
                                pushState: true,
                                search: false,
                                recordCount: false,
                                perPageSelect: false
                            },
                            dataset: {
                                records: JSON.parse(JSON.stringify(data).replace(/null/g, '"-"'))
                            }
                        }).data("dynatable");
                    } else {
                        SETTINGS.alltimewinnerstable.settings.dataset.originalRecords = results;
                        SETTINGS.alltimewinnerstable.process();
                    }
                },
                error: this.ErrorHandler
            });
        };

        BuildAllTimeSeriesDropDown = function () {
            var year = $('#alltime-year-option').val();
            $.ajax({
                type: "GET",
                dataType: "json",
                url: SETTINGS.Environment + '/Services/IndyStats.svc/AllTimeWinnerSeriesByYear?year=' + year,
                success: function (data) {
                    var dataLength = data.length;
                    $('#alltime-series-option').empty();
                    for (var i = 0; i < dataLength; i++) {
                        $('#alltime-series-option')
                            .append($("<option></option>")
                            .attr("value", data[i].SeriesID)
                            .text(data[i].Name));
                        console.log(data[i].Name);
                    }
                    AllTimeSeriesChanged();
                },
                error: this.ErrorHandler
            });
        };


        HideDriverTables = function () {
            $("#all-driver").hide();
            $("#year-driver").hide();
            $("#event-driver").hide();
        };

        HideSeasonTables = function () {
            $("#race-season").hide();
            $("#qual-season").hide();
            $("#qual-oval-season").hide();
            $("#qual-indy-season").hide();
            $("#practice-season").hide();
        };

        ErrorHandler = function (msg) {
            if (SETTINGS.isDebug) {
                console.log(msg);
            }
        };

        return Stats;

    })();
});