define(["jquery", "onscreen"], function ($) {
    var Tabs;
    return Tabs = (function () {
        function Tabs(options) {
            this.options = options;
            this.options = $.extend({}, this.defaults(), this.options);
            this.delegateEvents();
        }

        Tabs.prototype.defaults = function () {
            return {
                element: "#raceInfo",
                active: "--active",
                navItem: ".tabs-module__tab-link",
                navClass: "tabs-module__tab-link",
                contentItem: ".tabs-module__tab-content",
                contentItemClass: "tabs-module__tab-content",
                callback: function (item) { }
            };
        };

        Tabs.prototype.delegateEvents = function () {
            var _self;
            _self = this;
            this.options.$element = $(this.options.element);
            this.options.$navItem = $(this.options.navItem);
            this.options.$contentItem = $(this.options.contentItem);
            this.options.activeTab = this.options.navClass + this.options.active;
            this.options.activeContent = this.options.contentItemClass + this.options.active;
            return this.options.$navItem.on("click", function (e) {
                var $this, target;
                e.preventDefault();
                $this = $(this);
                target = $this.attr("href");
                if (target == null)
                { target = $this.attr("data-target"); }
                _self.options.$navItem.removeClass(_self.options.activeTab);
                $this.addClass(_self.options.activeTab);
                _self.options.$element.find("." + _self.options.activeContent).removeClass(_self.options.activeContent);
                return _self.options.$contentItem.each(function () {
                    var tab;
                    tab = $(this).attr("data-tab");
                    if (target === tab) {
                        $(this).addClass(_self.options.activeContent);
                        _self.options.callback();
                        return false;
                    }
                });
            });
        };

        return Tabs;

    })();
});
