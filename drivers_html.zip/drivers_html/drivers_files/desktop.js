require.config({
    baseUrl: "/scripts/indycar",
    waitSeconds: 1000,
    urlArgs: "bust=v2",
    paths: {
        jquery: "//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min",
        "jquery.ui": "//code.jquery.com/ui/1.13.1/jquery-ui",
        "jquery.mobile.events": "vendor/jquery.mobile.events",
        "slick": "//cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min",
        "fastclick": "//cdnjs.cloudflare.com/ajax/libs/fastclick/1.0.6/fastclick.min",
        "svg4everybody": "vendor/svg4everybody.min",
        "onscreen": "vendor/on.screen.min",
        "modernizr": "https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min",
        "jsrender": "//cdnjs.cloudflare.com/ajax/libs/jsrender/0.9.81/jsrender.min",
        "dynatable": "vendor/jquery.dynatable",
        "sharethis": "//platform-api.sharethis.com/js/sharethis.js#property=5ab00e7ca63ccf001315afb3&product=inline-share-buttons",
        "font-awesome": "//kit.fontawesome.com/0d551c6f47",
        "svg":"//cdnjs.cloudflare.com/ajax/libs/svg.js/3.1.2/svg.min"
        //"bootstrap": "//maxcdn.bootstrapcdn.com/bootstrap/4.2.0/js/bootstrap.min",
        //"popper": "//cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min"
    },
    shim: {
        "dynatable": {
            deps: ["jquery"]
        },
        "jquery.mobile.events": {
            deps: ["jquery"]
        },
        "onscreen": {
            deps: ["jquery"]
        },
        "slick": {
            deps: ["jquery"]
        },
        "vendor/highcharts-custom": {
            deps: ["jquery"]
        },
        "vendor/jquery.sharrre.min": {
            deps: ["jquery"]
        },
        //"bootstrap": {
        //    deps: ["jquery","popper"]
        //}
    }
});

require(["base/init"]);
