define(["jquery", "slick", "onscreen"], function ($) {
    var Slider;
    return Slider = (function () {
        function Slider(options) {
            this.options = options;
            this.options = $.extend({}, this.defaults(), this.options);
            this.delegateEvents();
        }

        Slider.prototype.defaults = function () {
            return {
                element: ".affiliates__affliates-list",
                arrows: false,
                dots: true,
                slidesToShow: 1,
                slidesToScroll: 1,
                prevArrow: "",
                nextArrow: "",
                autoPlay: false,
                autoPlaySpeed: 4500
            };
        };

        Slider.prototype.delegateEvents = function () {
            var _self;
            _self = this;
            this.options.$element = $(this.options.element);
            return _self.options.$element.each(function () {
                var $this;
                $this = $(this);
                return $this.slick({
                    arrows: _self.options.arrows,
                    dots: _self.options.dots,
                    slidesToShow: _self.options.slidesToShow,
                    slidesToScroll: _self.options.slidesToScroll,
                    prevArrow: _self.options.prevArrow,
                    nextArrow: _self.options.nextArrow,
                    autoplay: _self.options.autoPlay,
                    autoplaySpeed: _self.options.autoPlaySpeed
                });
            });
        };

        return Slider;

    })();
});
